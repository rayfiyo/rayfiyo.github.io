---
layout: default
title: My Links
---

<!-- # Links -->
* [Twitter🦜](https://twitter.com/rayfiyo)
* [GitHub🐱](https://github.com/rayfiyo)
* [Bluesky🟦@SNS](https://bsky.app/profile/rayfiyo.bsky.social)
* [Zenn🔷@Published articles](https://zenn.dev/rayfiyo)
* [Qiita🟢@Published articles](https://qiita.com/rayfiyo)
* Discord @Chat tool: rayfiyo
